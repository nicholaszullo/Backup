# Part D
## GRU
10 epochs, 512 hidden size, 256 embedding dim

## JULIET to start
JULIET:
So with the Barnardine; there were as bring me:
And knock her, the no man hath brought we be uning
days; make all on my friends are now
and towards, all thin and respected franding.

MAMILLIUS:
Nay, good sweet wrongonants, the strencts offended
us: he, if we looked you; but well incanning
To Gody dreadful friendly; for ever the nobles
Of the time advanced, and bribe profane;
But says king is nobly counterfeit to March,
Thou and both occasion with and dovest water
To thee. so can desperate health,
And valou'd time with his own fools.

KING RICHARD III:
Blessed Dispronous, tend me the tribunes
To such as the fitth to continue your prayer
Of this witness and great stocks and set
Envioural curegement but the twenty.

Nurse.

LADY ANNE:
Why, proceeding, I will your bocks
In their dukedom numbers for back-work.

Third Regard alike.

GLOUCESTER:
My gracious Lord that ensue once ask you.

CLAUDIO:
By the royal great action;
Give me knock the crown and that.

COMINIUS:
Well used your stones,


## ROMEO to start
ROMEO:
They did cure what rich for your own asper here!

KATHARINA:
What dost thou not say we through the truth from them
herein of devised it and a thousand-superful;
Sining counsel a next bush the world.

ANTONIO:
No horse, the power where you shall know how a word
That trust-wind and crabst me no more.

LEONTES:
Mocking me as hand:' a deceived from the
Those faith, only in happy dead, whom judged
here's a town to have: alas! what swear it?

QUEEN ELIZABETH:
Undonment, peace and loath to tell thee--

GREMIO:
Yes comes these eyes no less stamp. You have seen them:
Let it be brieved at the peese-grain.

MIRANDA:
Is that your honour and your days?

ALONAS: Hence!

ETSAREL:
I might be gone of his point of yord.

BRATHBOR LAUDREY:
An affair, to doom no more: that I too, no:
That more looks shall have the five and thee.

DUKE OF YORK:
Wrench time to his business; adventure spence woman of the
crief: high, speak?

ROMEO:
O whom; if no more blood tell him; our ward,
I hope to the piteous lovely i