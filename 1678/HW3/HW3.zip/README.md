# Running instructions
Please upload the files from the zip and to run in colab. I did not include the datasets in the zip to save space. Ensure that the datasets are in a folder "pacs_dataset/" for part A, and "data/" for C and D; or change the code to not look for these directories. All work was done locally, with the exception of part D I had to train on colab. 

Please write any shell commands needed to run the files.