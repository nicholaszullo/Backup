
import java.util.LinkedList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
		AssemblerTest test = new AssemblerTest();
		test.test1();
		test.test2();
    }
}
